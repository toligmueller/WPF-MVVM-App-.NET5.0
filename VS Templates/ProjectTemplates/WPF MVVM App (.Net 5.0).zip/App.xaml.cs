﻿using System;
using System.Configuration;
using System.Globalization;
using System.Threading.Tasks;
using System.Windows;
using Serilog;

namespace $safeprojectname$
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    { 
        public App()
        {
            // logging
            string outputTemplate = "[{Timestamp:HH:mm:ss} {Level:u3}] {Message:lj}{NewLine}{Exception}";
            Log.Logger = new LoggerConfiguration()
                    .ReadFrom.AppSettings()
                    .WriteTo.Debug(outputTemplate: outputTemplate)
                    .WriteTo.File("logs/app.log", outputTemplate: outputTemplate, rollingInterval: RollingInterval.Day, rollOnFileSizeLimit: true)
                    .CreateLogger();
            Log.Verbose("Logger initialized");

            // global exception handler
            AppDomain.CurrentDomain.UnhandledException += AppDomainCurrentDomainUnhandledExceptionHandler;
            Dispatcher.UnhandledException += DispatcherUnhandledExceptionHandler;
            Current.DispatcherUnhandledException += CurrentDispatcherUnhandledExceptionHandler;
            TaskScheduler.UnobservedTaskException += TaskSchedulerUnobservedTaskExceptionHandler;
            Log.Verbose("Global exception handler initialized");

            // loading UI/UX culture
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            $safeprojectname$.Properties.Resources.Culture = new CultureInfo(config.AppSettings.Settings["culture"].Value);
            Log.Verbose("Set culture to " + config.AppSettings.Settings["culture"].Value);

            Log.Verbose("App initialized");
        }

        ~App()
        {
            Log.Verbose("App finalized");
        }

        #region global exception handling
        private void TaskSchedulerUnobservedTaskExceptionHandler(object sender, UnobservedTaskExceptionEventArgs e)
        {
            GlobalExceptionHandler(e.Exception); 
        }

        private void CurrentDispatcherUnhandledExceptionHandler(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            GlobalExceptionHandler(e.Exception);
        }

        private void DispatcherUnhandledExceptionHandler(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            GlobalExceptionHandler(e.Exception);
        }

        private void AppDomainCurrentDomainUnhandledExceptionHandler(object sender, UnhandledExceptionEventArgs e)
        {
            GlobalExceptionHandler(e.ExceptionObject.ToString());
        }

        private void GlobalExceptionHandler(Exception ex)
        {
            Log.Error(ex, ex.Message);
        }
        private void GlobalExceptionHandler(string message)
        {
            Log.Error(message);
        }
        #endregion
    }
}
