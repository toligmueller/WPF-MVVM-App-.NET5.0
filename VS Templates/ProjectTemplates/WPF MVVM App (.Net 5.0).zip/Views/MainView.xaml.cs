﻿using System.Windows;
using System.Windows.Input;

namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for MainView.xaml
    /// </summary>
    public partial class MainView : Window
    {
        public MainView()
        {
            InitializeComponent();
        }

        private void ControlFocusLose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ((dynamic)sender).Focus();
        }
    }
}
