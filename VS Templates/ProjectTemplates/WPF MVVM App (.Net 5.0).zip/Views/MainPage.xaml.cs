﻿using System.Windows.Controls;
using System.Windows.Input;

namespace $safeprojectname$.Views
{
    /// <summary>
    /// Interaction logic for MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void ControlFocusLose_MouseDown(object sender, MouseButtonEventArgs e)
        {
            ((dynamic)sender).Focus();
        }
    }
}
