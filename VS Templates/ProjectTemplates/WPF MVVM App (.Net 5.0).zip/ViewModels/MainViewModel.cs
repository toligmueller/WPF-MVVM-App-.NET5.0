﻿using System;
using System.Windows;
using System.Configuration;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Messaging;
using Microsoft.Toolkit.Mvvm.Input.Wpf;
using Serilog;
using $safeprojectname$.Services;

namespace $safeprojectname$.ViewModels
{
    public class MainViewModel : ObservableObject
    {
        /// <summary>
        /// Frame navigation service
        /// </summary>
        public IFrameNavigationService FrameNavigationService { get; }

        /// <summary>
        /// Primary window 
        /// </summary>
        /// <param name="frameNavigationService"></param>
        public MainViewModel(IFrameNavigationService frameNavigationService)
        {
            FrameNavigationService = frameNavigationService;

            if (Application.Current.MainWindow == null)
            {
                // In design values
            }
            else
            {
                // Runtime values
            }
            Log.Verbose(nameof(MainViewModel) + " initialized");
        }
        ~MainViewModel()
        {
            Log.Verbose(nameof(MainViewModel) + " finalized");
        }

        /// <summary>
        /// Status if any process is running
        /// </summary>
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                {
                    Log.Verbose("IsBusy (" + nameof(MainViewModel) + "):" + value);
                    // Raise Update for all Commands
                    OnPropertyChanged(nameof(ChangeCultureCmd));
                }
            }
        }
        private bool _isBusy;

        /// <summary>
        /// Command to change culture
        /// </summary>
        public RelayCommand<string> ChangeCultureCmd => new(
             culture =>
             {
                 IsBusy = true;
                 
                 Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                 config.AppSettings.Settings["culture"].Value = culture;
                 config.Save();

                 Log.Verbose("Changed culture to " + culture);
                 Log.Information("Application restart required");

                 IsBusy = false;
             },
             _ => !IsBusy
         );
    }
}
