﻿using System;
using System.Windows;
using Microsoft.Extensions.DependencyInjection;
using $safeprojectname$.Services;

namespace $safeprojectname$.ViewModels
{
    public class ViewModelLocator
    {
        public IServiceProvider Services { get; }

        public MainViewModel MainVM => Services.GetService<MainViewModel>();
        public MainPageViewModel MainPageVM => Services.GetService<MainPageViewModel>();

        public ViewModelLocator()
        {
            Services = GetServices();
        }

        private static IServiceProvider GetServices()
        {
            IServiceCollection serviceCollection = new ServiceCollection();

            // Framework service with default content view
            serviceCollection.AddSingleton<IFrameNavigationService>(new FrameNavigationService(new Uri("Views/MainPage.xaml", UriKind.RelativeOrAbsolute)));

            if (Application.Current.MainWindow == null)
            {
                // In design services
            }
            else
            {
                // Runtime services
            }

            serviceCollection.AddSingleton<MainViewModel>();
            serviceCollection.AddSingleton<MainPageViewModel>();

            return serviceCollection.BuildServiceProvider();
        }
    }
}
