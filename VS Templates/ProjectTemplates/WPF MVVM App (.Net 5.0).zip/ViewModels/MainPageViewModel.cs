﻿using System;
using System.Windows;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Messaging;
using Microsoft.Toolkit.Mvvm.Input.Wpf;
using Serilog;

namespace $safeprojectname$.ViewModels
{
    public class MainPageViewModel : ObservableRecipient
    {
        /// <summary>
        /// Primary content view
        /// </summary>
        public MainPageViewModel()
        {
            // Enable messenger
            IsActive = true;
            if (Application.Current.MainWindow == null)
            {
                // In design values
            }
            else
            {
                // Runtime values
            }
            Log.Verbose(nameof(MainPageViewModel) + " initialized");
        }
        ~MainPageViewModel()
        {
            // Disable messenger
            IsActive = false;
            Log.Verbose(nameof(MainPageViewModel) + " finalized");
        }

        /// <summary>
        /// Status if any process is running
        /// </summary>
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                {
                    Log.Verbose("IsBusy (" + nameof(MainPageViewModel) + "):" + value);
                    // Raise Update for all Commands

                }
            }
        }
        private bool _isBusy;
    }
}
