﻿using System;
using System.Windows;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Messaging;
using Microsoft.Toolkit.Mvvm.Input.Wpf;
using Serilog;

namespace $rootnamespace$
{
    public class $safeitemname$ViewModel : ObservableRecipient
    {
        /// <summary>
        ///
        /// </summary>
        public $safeitemname$ViewModel()
        {
            // Enable messenger
            IsActive = true;
            if (Application.Current.MainWindow == null)
            {
                // In design values
            }
            else
            {
                // Runtime values
            }
            Log.Verbose(nameof($safeitemname$ViewModel) + " initialized");
        }

        ~$safeitemname$ViewModel()
        {
            // Disable messenger
            IsActive = false;
            Log.Verbose(nameof($safeitemname$ViewModel) + " finalized");
        }

        /// <summary>
        /// Status if any process is running
        /// </summary>
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                {
                    Log.Verbose("IsBusy (" + nameof($safeitemname$ViewModel) + "):" + value);
                    // Raise Update for all Commands

                }
            }
        }
        private bool _isBusy;
    }
}
