﻿using System;
using System.Windows;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Microsoft.Toolkit.Mvvm.Input.Wpf;
using Serilog;

namespace $rootnamespace$
{
    public class $safeitemname$$safeitemname$ : ObservableObject
    {
        /// <summary>
        ///
        /// </summary>
        public $safeitemname$$safeitemname$()
        {
            if (Application.Current.MainWindow == null)
            {
                // In design values
            }
            else
            {
                // Runtime values
            }
            Log.Verbose(nameof($safeitemname$$safeitemname$) + " initialized");
        }

        ~$safeitemname$$safeitemname$()
        {
            Log.Verbose(nameof($safeitemname$$safeitemname$) + " finalized");
        }

        /// <summary>
        /// Status if any process is running
        /// </summary>
        public bool IsBusy
        {
            get => _isBusy;
            set
            {
                if (SetProperty(ref _isBusy, value))
                {
                    Log.Verbose("IsBusy (" + nameof($safeitemname$$safeitemname$) + "):" + value);
                    // Raise Update for all Commands

                }
            }
        }
        private bool _isBusy;
    }
}
