﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;
using Microsoft.Toolkit.Mvvm.ComponentModel;
using Serilog;

namespace $rootnamespace$
{
    public class $safeitemname$Collection : ObservableCollection<$safeitemname$>
    {
        public $safeitemname$Collection() : base() { }

        public $safeitemname$Collection(ObservableCollection<$safeitemname$> value) : base(value) { }

        public $safeitemname$Collection(List<$safeitemname$> value) : base(value) { }

        public $safeitemname$Collection(IEnumerable<$safeitemname$> value) : base(value) { }
        }

    public class $safeitemname$ : ObservableObject, IDataErrorInfo
    {
        /// <summary>
        /// 
        /// </summary>
        public $safeitemname$()
        {
            Log.Verbose(nameof($safeitemname$) + " initialized");
        }

        ~$safeitemname$()
        {
            Log.Verbose(nameof($safeitemname$) + " finalized");
        }

        public string Error => null;

        public string this[string columnName]
        {
            get
            {
                switch (columnName)
                {

                }
                return string.Empty;
            }
        }
    }
}