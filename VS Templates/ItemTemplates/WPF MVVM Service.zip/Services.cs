﻿using System;
using Serilog;

namespace $rootnamespace$
{
    public interface I$safeitemname$Service
    {

    }

    public class $safeitemname$Service : I$safeitemname$Service
    {
        /// <summary>
        /// 
        /// </summary>
        public $safeitemname$Service()
        {
            Log.Verbose(nameof($safeitemname$Service) + " initialized");
        }

        ~$safeitemname$Service()
        {
            Log.Verbose(nameof($safeitemname$Service) + " finalized");
        }
    }
}
