﻿using Microsoft.Toolkit.Mvvm.Messaging.Messages;

namespace $rootnamespace$
{
    public class $safeitemname$Channel : ValueChangedMessage<string>
    {
        public $safeitemname$Channel(string msg) : base(msg) { }
    }

    public class $safeitemname$Request: RequestMessage<string> { }
}
